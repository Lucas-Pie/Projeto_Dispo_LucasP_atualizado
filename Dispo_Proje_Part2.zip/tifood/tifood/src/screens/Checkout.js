import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity, ScrollView, SafeAreaView, Alert } from 'react-native';
import { Picker } from '@react-native-picker/picker';

export default function Checkout({ navigation }) {
  const [nome, setNome] = useState('');
  const [telefone, setTelefone] = useState('');
  const [cep, setCep] = useState('');
  const [formaPagamento, setFormaPagamento] = useState('Cartão');

  const cepInvalido = cep.replace(/\D/g, '').length !== 8;

  const finalizarPedido = () => {
    if (!nome || !telefone || !cep) {
      Alert.alert('Erro', 'Preencha todos os campos.');
      return;
    }
    if (cepInvalido) {
      Alert.alert('Erro', 'O CEP deve conter 8 dígitos.');
      return;
    }
    Alert.alert('Sucesso', 'Pedido finalizado com sucesso!');
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.voltarTexto}>← Dados de Entrega</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Text style={styles.label}>Nome</Text>
        <TextInput 
          style={styles.input} 
          value={nome} 
          onChangeText={setNome} 
        />

        <Text style={styles.label}>Telefone</Text>
        <TextInput 
          style={styles.input} 
          value={telefone} 
          onChangeText={setTelefone} 
          keyboardType="phone-pad" 
        />

        <Text style={styles.label}>CEP</Text>
        <TextInput 
          style={[styles.input, cepInvalido && styles.inputErro]} 
          value={cep} 
          onChangeText={setCep} 
          keyboardType="numeric"
          maxLength={8}
        />
        {cepInvalido && <Text style={styles.textoErro}>▲ CEP deve ter 8 dígitos</Text>}

        <Text style={styles.label}>Pagamento</Text>
        <View style={styles.pickerWrapper}>
          <Picker
            selectedValue={formaPagamento}
            onValueChange={(itemValue) => setFormaPagamento(itemValue)}
            style={styles.picker}
          >
            <Picker.Item label="Cartão" value="Cartão" />
            <Picker.Item label="Pix" value="Pix" />
            <Picker.Item label="Dinheiro" value="Dinheiro" />
          </Picker>
        </View>

        <TouchableOpacity style={styles.botaoFinalizar} onPress={finalizarPedido}>
          <Text style={styles.botaoTexto}>Finalizar pedido</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  header: { backgroundColor: '#3b66f5', padding: 16, marginHorizontal: 16, marginTop: 16, borderRadius: 24 },
  voltarTexto: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  scrollContent: { padding: 24 },
  label: { fontSize: 15, fontWeight: 'bold', color: '#1f2937', marginBottom: 6, marginTop: 12 },
  input: { borderWidth: 1, borderColor: '#d1d5db', borderRadius: 12, padding: 12, fontSize: 16, backgroundColor: '#fff', color: '#1f2937' },
  inputErro: { borderColor: '#fca5a5', backgroundColor: '#fef2f2' },
  textoErro: { color: '#ef4444', fontSize: 13, marginTop: 4, marginLeft: 2 },
  pickerWrapper: { borderWidth: 1, borderColor: '#d1d5db', borderRadius: 12, backgroundColor: '#fff', overflow: 'hidden', marginTop: 4 },
  picker: { height: 50, width: '100%', color: '#1f2937', paddingHorizontal: 12, borderWidth: 0, backgroundColor: 'transparent' },
  botaoFinalizar: { backgroundColor: '#3b66f5', paddingVertical: 16, borderRadius: 24, alignItems: 'center', marginTop: 48, marginBottom: 16 },
  botaoTexto: { color: '#fff', fontSize: 18, fontWeight: 'bold' }
});
