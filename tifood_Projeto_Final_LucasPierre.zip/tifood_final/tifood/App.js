import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { CartProvider } from './src/context/CartContext';
import Cardapio from './src/screens/Cardapio';
import Carrinho from './src/screens/Carrinho';
import Checkout from './src/screens/Checkout';
import Confirmacao from './src/screens/Confirmacao';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <CartProvider>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Cardapio" screenOptions={{ headerShown: false }}>
          <Stack.Screen name="Cardapio" component={Cardapio} />
          <Stack.Screen name="Carrinho" component={Carrinho} />
          <Stack.Screen name="Checkout" component={Checkout} />
          <Stack.Screen name="Confirmacao" component={Confirmacao} />
        </Stack.Navigator>
      </NavigationContainer>
    </CartProvider>
  );
}
