import React, { useContext, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, TextInput, SafeAreaView } from 'react-native';
import { CartContext } from '../context/CartContext';

const lanchesLocais = [
  {
    id: 1,
    nome: 'X-Burger',
    ingredientes: 'Pão, carne, queijo',
    preco: 24.90,
    cor: '#ffb03b'
  },
  {
    id: 2,
    nome: 'X-Salada',
    ingredientes: 'Alface, tomate',
    preco: 27.90,
    cor: '#76c785'
  },
  {
    id: 3,
    nome: 'X-Bacon',
    ingredientes: 'Bacon crocante',
    preco: 29.90,
    cor: '#e76f6f'
  }
];

export default function Cardapio({ navigation }) {
  const { cart, addToCart } = useContext(CartContext);
  const [pesquisa, setPesquisa] = useState('');

  const produtosFiltrados = lanchesLocais.filter((produto) =>
    produto.nome.toLowerCase().includes(pesquisa.toLowerCase())
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>DelivExpress</Text>
        <TouchableOpacity style={styles.badgeContainer} onPress={() => navigation.navigate('Carrinho')}>
          <Text style={styles.badgeText}>{cart.length}</Text>
        </TouchableOpacity>
      </View>

      <TextInput 
        style={styles.searchBar} 
        placeholder="Buscar lanche..." 
        placeholderTextColor="#a0a0a0"
        value={pesquisa}
        onChangeText={setPesquisa}
      />

      <FlatList
        data={produtosFiltrados}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <View style={[styles.avatar, { backgroundColor: item.cor }]} />
            <View style={styles.infoContainer}>
              <Text style={styles.nome}>{item.nome}</Text>
              <Text style={styles.ingredientes}>{item.ingredientes}</Text>
              <Text style={styles.preco}>R$ {item.preco.toFixed(2).replace('.', ',')}</Text>
            </View>
            <TouchableOpacity style={styles.botaoAdd} onPress={() => addToCart(item)}>
              <Text style={styles.textoBotaoAdd}>+ Add</Text>
            </TouchableOpacity>
          </View>
        )}
        contentContainerStyle={{ paddingBottom: 24 }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#3b66f5', padding: 16, marginHorizontal: 16, marginTop: 16, borderRadius: 24 },
  headerTitle: { color: '#fff', fontSize: 20, fontWeight: 'bold' },
  badgeContainer: { backgroundColor: '#10b981', width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  badgeText: { color: '#fff', fontWeight: 'bold', fontSize: 14 },
  searchBar: { backgroundColor: '#f3f4f6', margin: 16, padding: 14, borderRadius: 12, fontSize: 16, borderWidth: 1, borderColor: '#e5e7eb' },
  card: { flexDirection: 'row', backgroundColor: '#fff', marginHorizontal: 16, marginVertical: 8, padding: 16, borderRadius: 16, alignItems: 'center', borderWidth: 1, borderColor: '#f3f4f6', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 8, elevation: 2 },
  avatar: { width: 64, height: 64, borderRadius: 12 },
  infoContainer: { flex: 1, marginLeft: 16 },
  nome: { fontSize: 18, fontWeight: 'bold', color: '#1f2937' },
  ingredientes: { fontSize: 14, color: '#6b7280', marginVertical: 4 },
  preco: { fontSize: 16, fontWeight: 'bold', color: '#ef4444' },
  botaoAdd: { backgroundColor: '#10b981', paddingVertical: 8, paddingHorizontal: 16, borderRadius: 12 },
  textoBotaoAdd: { color: '#fff', fontWeight: 'bold', fontSize: 14 }
});
