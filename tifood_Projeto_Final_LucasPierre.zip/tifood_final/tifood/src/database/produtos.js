export const PRODUTOS = [
  {
    id: '1',
    nome: 'X-Burger',
    descricao: 'Pão, carne, queijo',
    preco: 24.90,
   
  },
  {
    id: '2',
    nome: 'X-Salada',
    descricao: 'Alface, tomate, queijo',
    preco: 27.90,
   
  },
  {
    id: '3',
    nome: 'X-Bacon',
    descricao: 'Bacon crocante, carne',
    preco: 29.90,

  },
  {
    id: '4',
    nome: 'Batata Frita',
    descricao: 'Porção individual crocante',
    preco: 15.00,
  },
  {
    id: '5',
    nome: 'Refrigerante Lata',
    descricao: 'Coca-Cola ou Guaraná 350ml',
    preco: 6.00,
 
  }
];
