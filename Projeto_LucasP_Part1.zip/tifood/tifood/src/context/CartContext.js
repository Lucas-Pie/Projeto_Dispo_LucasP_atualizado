import React, { createContext, useState, useContext } from 'react';

const CartContext = createContext();

export function CartProvider({ children }) {
  const [cart, setCart] = useState([]);

  const adicionarAoCarrinho = (produto) => {
    setCart((itemsAtuais) => {
      const itemExiste = itemsAtuais.find((item) => item.id === produto.id);
      if (itemExiste) {
        return itemsAtuais.map((item) =>
          item.id === produto.id ? { ...item, quantidade: item.quantidade + 1 } : item
        );
      }
      return [...itemsAtuais, { ...produto, quantidade: 1 }];
    });
  };

  const alterarQuantidade = (id, tipo) => {
    setCart((itemsAtuais) =>
      itemsAtuais
        .map((item) => {
          if (item.id === id) {
            const novaQtd = tipo === 'somar' ? item.quantidade + 1 : item.quantidade - 1;
            return { ...item, quantidade: novaQtd };
          }
          return item;
        })
        .filter((item) => item.quantidade > 0)
    );
  };

  const totalItens = cart.reduce((acc, item) => acc + item.quantidade, 0);

  return (
    <CartContext.Provider value={{ cart, adicionarAoCarrinho, alterarQuantidade, totalItens }}>
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => useContext(CartContext);
