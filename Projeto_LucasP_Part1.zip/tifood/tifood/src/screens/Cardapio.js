import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, TextInput } from 'react-native';
import { PRODUTOS } from '../database/produtos';
import { useCart } from '../context/CartContext';


const CORES_PRODUTOS = {
  '1': '#FBBF24',
  '2': '#86EFAC', 
  '3': '#F87171', 
  '4': '#93C5FD',
  '5': '#FCA5A5', 
};

export default function CardapioScreen({ navigation }) {
  const { adicionarAoCarrinho, totalItens } = useCart();
  const [pesquisa, setPesquisa] = useState('');

  const produtosFiltrados = PRODUTOS.filter((produto) =>
    produto.nome.toLowerCase().includes(pesquisa.toLowerCase())
  );

  return (
    <View style={styles.container}>

      <View style={styles.header}>
        <Text style={styles.headerTitle}>TIFOOD</Text>
        <TouchableOpacity 
          style={styles.cartBadge} 
          onPress={() => navigation.navigate('Carrinho')}
        >
          <Text style={styles.cartBadgeText}>{totalItens}</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="🔍 Buscar lanche..."
          placeholderTextColor="#9CA3AF"
          value={pesquisa}
          onChangeText={setPesquisa}
        />
      </View>


      <FlatList
        data={produtosFiltrados}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <View style={[styles.imageMock, { backgroundColor: CORES_PRODUTOS[item.id] || '#E5E7EB' }]} />
            
            <View style={styles.info}>
              <Text style={styles.nome}>{item.nome}</Text>
              <Text style={styles.descricao}>{item.descricao}</Text>
              <Text style={styles.preco}>R$ {item.preco.toFixed(2).replace('.', ',')}</Text>
            </View>

            <TouchableOpacity style={styles.addButton} onPress={() => adicionarAoCarrinho(item)}>
              <Text style={styles.addButtonText}>+ Add</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFF' },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    backgroundColor: '#3B62F6', 
    height: 100,
    paddingTop: 40,
    borderBottomLeftRadius: 16,
    borderBottomRightRadius: 16,
  },
  headerTitle: { fontSize: 20, fontWeight: 'bold', color: '#FFF' },
  cartBadge: { backgroundColor: '#10B981', width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  cartBadgeText: { color: '#FFF', fontWeight: 'bold', fontSize: 14 },
  searchContainer: { paddingHorizontal: 20, marginTop: 16, marginBottom: 8 },
  searchInput: {
    backgroundColor: '#F3F4F6',
    height: 44,
    borderRadius: 22,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    paddingHorizontal: 16,
    fontSize: 15,
  },
  listContent: { paddingHorizontal: 20, paddingTop: 8 },
  card: {
    flexDirection: 'row',
    backgroundColor: '#F9FAFB',
    marginBottom: 12,
    borderRadius: 16,
    padding: 12,
    alignItems: 'center',
  },
  imageMock: { width: 64, height: 64, borderRadius: 12, marginRight: 16 },
  info: { flex: 1 },
  nome: { fontSize: 16, fontWeight: 'bold', color: '#1F2937' },
  descricao: { fontSize: 12, color: '#6B7280', marginVertical: 2 },
  preco: { fontSize: 15, fontWeight: 'bold', color: '#EF4444' }, 
  addButton: { backgroundColor: '#10B981', paddingVertical: 6, paddingHorizontal: 14, borderRadius: 20 },
  addButtonText: { color: '#FFF', fontWeight: 'bold', fontSize: 14 },
});