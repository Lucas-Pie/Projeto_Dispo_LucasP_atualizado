import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, TextInput } from 'react-native';
import { useCart } from '../context/CartContext';

export default function CarrinhoScreen({ navigation }) {
  const { cart, alterarQuantidade } = useCart();
  const [cupom, setCupom] = useState('');
  const [desconto, setDesconto] = useState(0);

  const TAXA_ENTREGA = 6.00;
const subtotal = cart.reduce((acc, item) => acc + item.preco * item.quantidade, 0);


  const aplicarCupom = () => {
    if (cupom.trim().toUpperCase() === 'ALUNO10') {
      setDesconto(subtotal * 0.10);
    } else {
      setDesconto(0);
      alert('Cupom inválido');
    }
  };

const total = subtotal > 0 ? (subtotal - desconto) + TAXA_ENTREGA : 0;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Text style={styles.headerTitle}>← Meu Carrinho</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={cart}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        renderItem={({ item }) => (
          <View style={styles.itemRow}>
            <View style={styles.itemInfo}>
              <Text style={styles.itemName}>{item.nome}</Text>
              <Text style={styles.itemPrice}>R$ {item.preco.toFixed(2).replace('.', ',')}</Text>
            </View>
            
            <View style={styles.rightSection}>
              <View style={styles.qtyContainer}>
                <TouchableOpacity style={styles.qtyBtn} onPress={() => alterarQuantidade(item.id, 'subtrair')}>
                  <Text style={styles.qtyBtnText}>-</Text>
                </TouchableOpacity>
                <Text style={styles.qtyText}>{item.quantidade}</Text>
                <TouchableOpacity style={styles.qtyBtn} onPress={() => alterarQuantidade(item.id, 'somar')}>
                  <Text style={styles.qtyBtnText}>+</Text>
                </TouchableOpacity>
              </View>
              <Text style={styles.itemSubtotal}>
                {(item.preco * item.quantidade).toFixed(2).replace('.', ',')}
              </Text>
            </View>
          </View>
        )}
      />

      {cart.length > 0 && (
        <View style={styles.couponSection}>
          <TextInput
            style={styles.couponInput}
            placeholder="Possui cupom? Ex: ALUNO10"
            value={cupom}
            onChangeText={setCupom}
            autoCapitalize="characters"
          />
          <TouchableOpacity style={styles.couponBtn} onPress={aplicarCupom}>
            <Text style={styles.couponBtnText}>Validar</Text>
          </TouchableOpacity>
        </View>
      )}

      <View style={styles.footerCard}>
        <View style={styles.footerRow}>
          <Text style={styles.footerLabel}>Subtotal</Text>
          <Text style={styles.footerValue}>R$ {subtotal.toFixed(2).replace('.', ',')}</Text>
        </View>
        {desconto > 0 && (
          <View style={styles.footerRow}>
            <Text style={[styles.footerLabel, { color: '#10B981' }]}>Desconto (10%)</Text>
            <Text style={[styles.footerValue, { color: '#10B981' }]}>- R$ {desconto.toFixed(2).replace('.', ',')}</Text>
          </View>
        )}
        <View style={styles.footerRow}>
          <Text style={styles.footerLabel}>Entrega</Text>
          <Text style={styles.footerValue}>R$ {TAXA_ENTREGA.toFixed(2).replace('.', ',')}</Text>
        </View>
        <View style={[styles.footerRow, { marginTop: 8 }]}>
          <Text style={styles.totalLabel}>TOTAL</Text>
          <Text style={styles.totalValue}>R$ {total.toFixed(2).replace('.', ',')}</Text>
        </View>
      </View>

      <View style={styles.actionContainer}>
        <TouchableOpacity 
          style={[styles.continueButton, cart.length === 0 && { opacity: 0.6 }]} 
          disabled={cart.length === 0}
          onPress={() => alert('Direcionando para o formulário de entrega...')}
        >
          <Text style={styles.continueButtonText}>Continuar</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFF' },
  header: {
    backgroundColor: '#3B62F6',
    height: 100,
    paddingTop: 40,
    paddingHorizontal: 20,
    justifyContent: 'center',
    borderBottomLeftRadius: 16,
    borderBottomRightRadius: 16,
  },
  headerTitle: { fontSize: 20, fontWeight: 'bold', color: '#FFF' },
  listContent: { paddingHorizontal: 20, paddingTop: 16 },
  itemRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  itemInfo: { flex: 1 },
  itemName: { fontSize: 16, fontWeight: 'bold', color: '#1F2937' },
  itemPrice: { fontSize: 14, color: '#6B7280', marginTop: 2 },
  rightSection: { alignItems: 'flex-end' },
  qtyContainer: { flexDirection: 'row', alignItems: 'center', marginBottom: 4 },
  qtyBtn: {
    borderWidth: 1,
    borderColor: '#3B62F6',
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  qtyBtnText: { color: '#3B62F6', fontWeight: 'bold', fontSize: 14, marginTop: -2 },
  qtyText: { marginHorizontal: 10, fontSize: 14, fontWeight: 'bold' },
  itemSubtotal: { fontSize: 15, fontWeight: 'bold', color: '#1F2937' },
  
  couponSection: { flexDirection: 'row', paddingHorizontal: 20, marginVertical: 8, gap: 8 },
  couponInput: { flex: 1, height: 40, borderInterf: 1, borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, paddingHorizontal: 12 },
  couponBtn: { backgroundColor: '#4B5563', paddingHorizontal: 16, borderRadius: 8, justifyContent: 'center' },
  couponBtnText: { color: '#FFF', fontWeight: 'bold' },

  footerCard: {
    backgroundColor: '#F9FAFB',
    margin: 20,
    padding: 16,
    borderRadius: 16,
  },
  footerRow: { flexDirection: 'row', justifyContent: 'space-between', marginVertical: 3 },
  footerLabel: { fontSize: 14, color: '#4B5563' },
  footerValue: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' },
  totalLabel: { fontSize: 16, fontWeight: 'bold', color: '#1F2937' },
  totalValue: { fontSize: 18, fontWeight: 'bold', color: '#10B981' }, 
  actionContainer: { paddingHorizontal: 20, marginBottom: 24 },
  continueButton: {
    backgroundColor: '#3B62F6',
    height: 50,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  continueButtonText: { color: '#FFF', fontSize: 16, fontWeight: 'bold' },
});