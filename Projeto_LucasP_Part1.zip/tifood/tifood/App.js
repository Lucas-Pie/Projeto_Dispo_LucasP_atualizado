import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { CartProvider } from './src/context/CartContext';

import CardapioScreen from './src/screens/Cardapio';
import CarrinhoScreen from './src/screens/Carrinho';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <CartProvider>
      <NavigationContainer>
        <Stack.Navigator 
          initialRouteName="Cardapio"
          screenOptions={{
            headerShown: false 
          }}
        >
          <Stack.Screen 
            name="Cardapio" 
            component={CardapioScreen} 
          />
          <Stack.Screen 
            name="Carrinho" 
            component={CarrinhoScreen} 
          />
        </Stack.Navigator>
      </NavigationContainer>
    </CartProvider>
  );
}
