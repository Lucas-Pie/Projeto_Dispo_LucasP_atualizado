import React, { useContext, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, TextInput, SafeAreaView, Image } from 'react-native';
import { CartContext } from '../context/CartContext';

const lanchesLocais = [
  {
    id: 1,
    nome: 'X-Burger',
    ingredientes: 'Pão, carne, queijo',
    preco: 24.90,
    imagem: { uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTKkmAZSeCJKnhgQXsPORhrXYA6Fd6-_sWUJruPHap1BA&s=10' }
  },
  {
    id: 2,
    nome: 'X-Salada',
    ingredientes: 'Alface, tomate',
    preco: 27.90,
    imagem: { uri: 'https://s2-receitas.glbimg.com/Td050XeFMOBB7XFeJigA5voIlvE=/0x0:1200x675/984x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_1f540e0b94d8437dbbc39d567a1dee68/internal_photos/bs/2024/7/K/ehv3mfQjmY0VivlyFd8g/x-salada-classico.jpg' }
  },
  {
    id: 3,
    nome: 'X-Bacon',
    ingredientes: 'Bacon crocante',
    preco: 29.90,
    imagem: { uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRDy9MOsFNrjCXT93S1dcMAyjPSCR4l6yL5Z21dnIvAMw&s=10' }
  }
];

export default function Cardapio({ navigation }) {
  const { cart, addToCart } = useContext(CartContext);
  const [pesquisa, setPesquisa] = useState('');

  const produtosFiltrados = lanchesLocais.filter((produto) =>
    produto.nome.toLowerCase().includes(pesquisa.toLowerCase())
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>DelivExpress</Text>
        <TouchableOpacity style={styles.badgeContainer} onPress={() => navigation.navigate('Carrinho')}>
          <Text style={styles.badgeText}>{cart.length}</Text>
        </TouchableOpacity>
      </View>

      <TextInput 
        style={styles.searchBar} 
        placeholder="Buscar lanche..." 
        placeholderTextColor="#464E5C"
        value={pesquisa}
        onChangeText={setPesquisa}
      />

      <FlatList
        data={produtosFiltrados}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Image source={item.imagem} style={styles.avatar} />
            <View style={styles.infoContainer}>
              <Text style={styles.nome}>{item.nome}</Text>
              <Text style={styles.ingredientes}>{item.ingredientes}</Text>
              <Text style={styles.preco}>R$ {item.preco.toFixed(2).replace('.', ',')}</Text>
            </View>
            <TouchableOpacity style={styles.botaoAdd} onPress={() => addToCart(item)}>
              <Text style={styles.textoBotaoAdd}>+ Add</Text>
            </TouchableOpacity>
          </View>
        )}
        contentContainerStyle={{ paddingBottom: 24 }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFF' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#3D5AFE', padding: 16, marginHorizontal: 16, marginTop: 16, borderRadius: 24 },
  headerTitle: { color: '#FFF', fontSize: 20, fontWeight: 'bold' },
  badgeContainer: { backgroundColor: '#2EC478', width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  badgeText: { color: '#FFF', fontWeight: 'bold', fontSize: 14 },
  searchBar: { backgroundColor: '#F2F4F7', margin: 16, padding: 14, borderRadius: 12, fontSize: 16, borderWidth: 1, borderColor: '#464E5C', color: '#202A44' },
  card: { flexDirection: 'row', backgroundColor: '#FFF', marginHorizontal: 16, marginVertical: 8, padding: 16, borderRadius: 16, alignItems: 'center', borderWidth: 1, borderColor: '#F2F4F7', shadowColor: '#202A44', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 8, elevation: 2 },
  avatar: { width: 64, height: 64, borderRadius: 12, backgroundColor: '#F2F4F7' },
  infoContainer: { flex: 1, marginLeft: 16 },
  nome: { fontSize: 18, fontWeight: 'bold', color: '#202A44' },
  ingredientes: { fontSize: 14, color: '#464E5C', marginVertical: 4 },
  preco: { fontSize: 16, fontWeight: 'bold', color: '#202A44' },
  botaoAdd: { backgroundColor: '#2EC478', paddingVertical: 8, paddingHorizontal: 16, borderRadius: 12 },
  textoBotaoAdd: { color: '#FFF', fontWeight: 'bold', fontSize: 14 }
});
