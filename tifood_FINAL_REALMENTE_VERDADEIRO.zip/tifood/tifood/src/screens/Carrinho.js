import React, { useContext, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, SafeAreaView, TextInput } from 'react-native';
import { CartContext } from '../context/CartContext';

export default function Carrinho({ navigation }) {
  const { cart, total, addToCart, removeFromCart } = useContext(CartContext);
  const [cupom, setCupom] = useState('');

  const itensAgrupados = cart.reduce((acc, item) => {
    const encontrado = acc.find(i => i.id === item.id);
    if (encontrado) {
      encontrado.quantidade += 1;
    } else {
      acc.push({ ...item, quantidade: 1 });
    }
    return acc;
  }, []);

  const subtotal = total;
  const desconto = cupom.trim().toUpperCase() === 'ALUNO10' ? subtotal * 0.10 : 0;
  const entrega = cart.length > 0 ? 6.00 : 0.00;
  const totalGeral = subtotal - desconto + entrega;

  const carrinhoVazio = cart.length === 0;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.voltarTexto}>← Meu Carrinho</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={itensAgrupados}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.itemCard}>
            <View style={styles.produtoInfo}>
              <Text style={styles.produtoNome}>{item.nome}</Text>
              <Text style={styles.produtoPreco}>R$ {item.preco.toFixed(2)}</Text>
            </View>
            <View style={styles.controleQuantidade}>
              <TouchableOpacity style={styles.botaoQtd} onPress={() => removeFromCart(item.id)}>
                <Text style={styles.textoBotaoQtd}>-</Text>
              </TouchableOpacity>
              <Text style={styles.quantidadeValor}>{item.quantidade}</Text>
              <TouchableOpacity style={styles.botaoQtd} onPress={() => addToCart(item)}>
                <Text style={styles.textoBotaoQtd}>+</Text>
              </TouchableOpacity>
              <Text style={styles.subtotalItem}>{(item.preco * item.quantidade).toFixed(2)}</Text>
            </View>
          </View>
        )}
        contentContainerStyle={{ paddingBottom: 16 }}
      />

      <View style={styles.cupomCaixa}>
        <Text style={styles.cupomLabel}>Cupom de Desconto</Text>
        <TextInput
          style={styles.cupomInput}
          placeholder="Digite seu cupom"
          placeholderTextColor="#464E5C"
          value={cupom}
          onChangeText={setCupom}
          autoCapitalize="characters"
        />
        {desconto > 0 && <Text style={styles.cupomSucesso}>✓ Cupom ALUNO10 aplicado! (10% de desconto)</Text>}
      </View>

      <View style={styles.resumoCaixa}>
        <View style={styles.resumoLinha}>
          <Text style={styles.resumoTexto}>Subtotal</Text>
          <Text style={styles.resumoValor}>R$ {subtotal.toFixed(2)}</Text>
        </View>
        {desconto > 0 && (
          <View style={styles.resumoLinha}>
            <Text style={[styles.resumoTexto, { color: '#2EC478' }]}>Desconto</Text>
            <Text style={[styles.resumoValor, { color: '#2EC478' }]}>- R$ {desconto.toFixed(2)}</Text>
          </View>
        )}
        <View style={styles.resumoLinha}>
          <Text style={styles.resumoTexto}>Entrega</Text>
          <Text style={styles.resumoValor}>R$ {entrega.toFixed(2)}</Text>
        </View>
        <View style={[styles.resumoLinha, { marginTop: 12 }]}>
          <Text style={styles.totalLabel}>TOTAL</Text>
          <Text style={styles.totalValor}>R$ {totalGeral.toFixed(2)}</Text>
        </View>
      </View>

      <TouchableOpacity 
        style={[styles.botaoContinuar, carrinhoVazio && styles.botaoDesabilitado]} 
        onPress={() => navigation.navigate('Checkout')}
        disabled={carrinhoVazio}
      >
        <Text style={styles.textoBotaoContinuar}>Continuar</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFF' },
  header: { backgroundColor: '#3D5AFE', padding: 16, marginHorizontal: 16, marginTop: 16, borderRadius: 24 },
  voltarTexto: { color: '#FFF', fontSize: 18, fontWeight: 'bold' },
  itemCard: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 16, marginHorizontal: 16, borderBottomWidth: 1, borderColor: '#F2F4F7' },
  produtoInfo: { flex: 1 },
  produtoNome: { fontSize: 18, fontWeight: 'bold', color: '#202A44' },
  produtoPreco: { fontSize: 14, color: '#464E5C', marginTop: 2 },
  controleQuantidade: { flexDirection: 'row', alignItems: 'center' },
  botaoQtd: { width: 28, height: 28, backgroundColor: '#F2F4F7', borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  textoBotaoQtd: { fontSize: 16, fontWeight: 'bold', color: '#3D5AFE' },
  quantidadeValor: { marginHorizontal: 12, fontSize: 16, fontWeight: 'bold', color: '#202A44' },
  subtotalItem: { marginLeft: 16, width: 60, textAlign: 'right', fontSize: 16, fontWeight: 'bold', color: '#202A44' },
  cupomCaixa: { paddingHorizontal: 16, marginVertical: 8 },
  cupomLabel: { fontSize: 14, fontWeight: 'bold', color: '#464E5C', marginBottom: 4 },
  cupomInput: { borderWidth: 1, borderColor: '#464E5C', borderRadius: 12, padding: 12, fontSize: 16, color: '#202A44' },
  cupomSucesso: { color: '#2EC478', fontSize: 13, marginTop: 4, fontWeight: '500' },
  resumoCaixa: { backgroundColor: '#F2F4F7', margin: 16, padding: 16, borderRadius: 16, borderWidth: 1, borderColor: '#464E5C' },
  resumoLinha: { flexDirection: 'row', justifyContent: 'space-between', marginVertical: 4 },
  resumoTexto: { fontSize: 16, color: '#464E5C' },
  resumoValor: { fontSize: 16, fontWeight: '500', color: '#202A44' },
  totalLabel: { fontSize: 18, fontWeight: 'bold', color: '#202A44' },
  totalValor: { fontSize: 18, fontWeight: 'bold', color: '#2EC478' },
  botaoContinuar: { backgroundColor: '#3D5AFE', marginHorizontal: 16, marginBottom: 24, paddingVertical: 16, borderRadius: 24, alignItems: 'center' },
  botaoDesabilitado: { backgroundColor: '#464E5C', opacity: 0.5 },
  textoBotaoContinuar: { color: '#FFF', fontSize: 18, fontWeight: 'bold' }
});
