import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, ScrollView, TouchableOpacity, Switch } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { useCart } from '../context/CartContext';

export default function Checkout({ navigation }) {
  const { cart, total } = useCart();

  const [nome, setNome] = useState('');
  const [telefone, setTelefone] = useState('');
  const [cep, setCep] = useState('');
  const [endereco, setEndereco] = useState('');
  const [numero, setNumero] = useState('');
  const [pagamento, setPagamento] = useState('');
  
  const [precisoTroco, setPrecisoTroco] = useState(false);
  const [trocoPara, setTrocoPara] = useState('');

  const [erros, setErros] = useState({});

  const handleTelefoneChange = (text) => {
    setTelefone(text.replace(/[^0-9]/g, ''));
  };

  const handleCepChange = (text) => {
    const limpo = text.replace(/[^0-9]/g, '');
    setCep(limpo);
    
    if (limpo.length === 8) {
      setErros((prev) => {
        const { cep, ...resto } = prev;
        return resto;
      });
    }
  };

  const handleNumeroChange = (text) => {
    setNumero(text.replace(/[^0-9]/g, ''));
  };

  const handlePagamentoChange = (opcao) => {
    setPagamento(opcao);
    if (opcao !== 'Dinheiro') {
      setPrecisoTroco(false);
      setTrocoPara('');
    }
  };

  const finalizarPedido = () => {
    let errosDetetados = {};

    if (cart.length === 0) {
      errosDetetados.carrinho = 'Seu carrinho está vazio.';
    }
    if (nome.trim() === '') {
      errosDetetados.nome = 'Informe seu nome.';
    }
    if (telefone.length < 10) {
      errosDetetados.telefone = 'Telefone inválido.';
    }
    if (cep.length !== 8) {
      errosDetetados.cep = 'CEP deve ter 8 dígitos.';
    }
    if (endereco.trim() === '') {
      errosDetetados.endereco = 'Informe o endereço.';
    }
     if (!/^[0-9]+/.test(numero)) {
      errosDetetados.numero = 'Número inválido.';
    }
    if (pagamento === '') {
      errosDetetados.pagamento = 'Escolha a forma de pagamento.';
    }

    setErros(errosDetetados);

    if (Object.keys(errosDetetados).length > 0) {
      return;
    }

    navigation.navigate('Confirmacao', {
      resumo: {
        itens: cart,
        total: total,
        endereco: `${endereco}, ${numero} - CEP: ${cep}`,
        formaPagamento: pagamento + (precisoTroco && trocoPara ? ` (Troco para R$ ${trocoPara})` : '')
      }
    });
  };

  return (
    <View style={styles.container}>
      <View style={styles.headerAzul}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
        <Text style={styles.headerTexto}>← Dados de Entrega</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {erros.carrinho && <Text style={styles.erroTextoGeral}>{erros.carrinho}</Text>}

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Nome</Text>
          <TextInput
            style={[styles.input, erros.nome && styles.inputErro]}
            value={nome}
            onChangeText={setNome}
            placeholder="Digite seu nome"
            placeholderTextColor="#A0A0A0"
          />
          {erros.nome && <Text style={styles.erroTexto}>⚠️ {erros.nome}</Text>}
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Telefone</Text>
          <TextInput
            style={[styles.input, erros.telefone && styles.inputErro]}
            value={telefone}
            onChangeText={handleTelefoneChange}
            placeholder="(19) 9 ____"
            placeholderTextColor="#A0A0A0"
            keyboardType="numeric"
            maxLength={11}
          />
          {erros.telefone && <Text style={styles.erroTexto}>⚠️ {erros.telefone}</Text>}
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>CEP</Text>
          <TextInput
            style={[styles.input, erros.cep && styles.inputErro]}
            value={cep}
            onChangeText={handleCepChange}
            placeholder="Ex: 13220000"
            placeholderTextColor="#A0A0A0"
            keyboardType="numeric"
            maxLength={8}
          />
          {erros.cep && <Text style={styles.erroTexto}>⚠️ {erros.cep}</Text>}
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Endereço</Text>
          <TextInput
            style={[styles.input, erros.endereco && styles.inputErro]}
            value={endereco}
            onChangeText={setEndereco}
            placeholder="Informe o endereço"
            placeholderTextColor="#A0A0A0"
          />
          {erros.endereco && <Text style={styles.erroTexto}>⚠️ {erros.endereco}</Text>}
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Número</Text>
          <TextInput
            style={[styles.input, erros.numero && styles.inputErro]}
            value={numero}
            onChangeText={handleNumeroChange}
            placeholder="Número"
            placeholderTextColor="#A0A0A0"
            keyboardType="numeric"
          />
          {erros.numero && <Text style={styles.erroTexto}>⚠️ {erros.numero}</Text>}
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Forma de Pagamento</Text>
          <View style={[styles.pickerContainer, erros.pagamento && styles.pickerErro]}>
            <Picker
              selectedValue={pagamento}
              onValueChange={(itemValue) => handlePagamentoChange(itemValue)}
              style={styles.picker}
              dropdownIconColor="#4466FF"
            >
              <Picker.Item label="Selecione uma opção..." value="" color="#A0A0A0" />
              <Picker.Item label="Dinheiro" value="Dinheiro" />
              <Picker.Item label="Cartão" value="Cartão" />
              <Picker.Item label="Pix" value="Pix" />
            </Picker>
          </View>
          {erros.pagamento && <Text style={styles.erroTexto}>⚠️ {erros.pagamento}</Text>}
        </View>

        {pagamento === 'Dinheiro' && (
          <View style={styles.containerTroco}>
            <View style={styles.linhaSwitch}>
              <Text style={styles.labelTroco}>Preciso de troco</Text>
              <Switch
                value={precisoTroco}
                onValueChange={setPrecisoTroco}
                trackColor={{ false: '#767577', true: '#4466FF' }}
                thumbColor={precisoTroco ? '#FFF' : '#f4f3f4'}
              />
            </View>

            {precisoTroco && (
              <View style={styles.inputGroupTroco}>
                <Text style={styles.label}>Troco para quanto?</Text>
                <TextInput
                  style={styles.input}
                  value={trocoPara}
                  onChangeText={(text) => setTrocoPara(text.replace(/[^0-9]/g, ''))}
                  placeholder="Ex: 50"
                  placeholderTextColor="#A0A0A0"
                  keyboardType="numeric"
                />
              </View>
            )}
          </View>
        )}
      </ScrollView>

      <View style={styles.footer}>
        <TouchableOpacity style={styles.btnFinalizar} onPress={finalizarPedido}>
          <Text style={styles.btnFinalizarText}>Finalizar pedido</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF'
  },
  headerAzul: {
    backgroundColor: '#4466FF',
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderRadius: 14,
    marginTop: 20,
    marginHorizontal: 16,
    alignItems: 'flex-start'
  },
  headerTexto: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold'
  },
  scrollContent: {
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: 30
  },
  inputGroup: {
    marginBottom: 16
  },
  label: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#2C3E50',
    marginBottom: 6
  },
  input: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 16,
    fontSize: 14,
    color: '#333',
    backgroundColor: '#FAFAFA'
  },
  inputErro: {
    borderColor: '#EB5757',
    backgroundColor: '#FDF2F2'
  },
  pickerContainer: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 12,
    backgroundColor: '#FAFAFA',
    overflow: 'hidden',
    justifyContent: 'center'
  },
  pickerErro: {
    borderColor: '#EB5757',
    backgroundColor: '#FDF2F2'
  },
  picker: {
    width: '100%',
    color: '#333'
  },
  erroTexto: {
    color: '#EB5757',
    fontSize: 12,
    marginTop: 6,
    fontWeight: '500'
  },
  erroTextoGeral: {
    color: '#EB5757',
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center'
  },
  containerTroco: {
    backgroundColor: '#FAFAFA',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    marginTop: 8
  },
  linhaSwitch: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  labelTroco: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#2C3E50'
  },
  inputGroupTroco: {
    marginTop: 12
  },
  footer: {
    paddingHorizontal: 24,
    paddingBottom: 20,
    alignItems: 'center',
    backgroundColor: '#FFF'
  },
  btnFinalizar: {
    backgroundColor: '#4466FF',
    width: '100%',
    paddingVertical: 14,
    borderRadius: 16,
    alignItems: 'center',
    marginBottom: 8
  },
  btnFinalizarText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold'
  },
  tagTela: {
    fontSize: 13,
    color: '#4466FF',
    fontWeight: 'bold'
  }
});
