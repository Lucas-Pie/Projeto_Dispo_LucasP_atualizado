import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { useCart } from '../context/CartContext';

export default function Confirmacao({ navigation, route }) {
  const { clearCart } = useCart();
  const { resumo } = route.params || {};
  const [numeroPedido, setNumeroPedido] = useState('');

  useEffect(() => {
    const numeroAleatorio = Math.floor(1000 + Math.random() * 9000);
    setNumeroPedido(`#${numeroAleatorio}`);
    Alert.alert('Sucesso!', 'Seu pedido foi recebido com sucesso!');
  }, []);

  const handleNovoPedido = () => {
    clearCart();
    navigation.reset({
      index: 0,
      routes: [{ name: 'Cardapio' }],
    });
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        
        <View style={styles.iconeCirculo}>
          <Text style={styles.iconeCheck}>✓</Text>
        </View>

        <Text style={styles.titulo}>Pedido confirmado!</Text>
        <Text style={styles.pedidoNumero}>Pedido {numeroPedido}</Text>

        <View style={styles.divisor} />

        <View style={styles.itensContainer}>
          {resumo?.itens?.map((item, index) => (
            <Text key={index} style={styles.itemTexto}>
              {item.quantidade || 1}x {item.nome}
            </Text>
          )) || (
            <>
              <Text style={styles.itemTexto}>2x X-Burger</Text>
              <Text style={styles.itemTexto}>1x X-Salada</Text>
            </>
          )}
        </View>

        <View style={styles.divisor} />

        <View style={styles.infoBloco}>
          <View style={styles.linhaTotal}>
            <Text style={styles.totalLabel}>Total pago</Text>
            <Text style={styles.totalValor}>
              R\$ {resumo?.total ? resumo.total.toFixed(2).replace('.', ',') : '83,70'}
            </Text>
          </View>

          <Text style={styles.detalheTexto}>
            Entrega: {resumo?.endereco || 'Rua A, 123'}
          </Text>
          <Text style={styles.detalheTexto}>
            Pagamento: {resumo?.formaPagamento || 'Cartão'}
          </Text>
        </View>

      </ScrollView>

      <View style={styles.footer}>
        <TouchableOpacity style={styles.btnNovoPedido} onPress={handleNovoPedido}>
          <Text style={styles.btnNovoPedidoText}>Fazer novo pedido</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#FFF' 
  },
  scrollContent: { 
    alignItems: 'center', 
    paddingTop: 40, 
    paddingHorizontal: 25 
  },
  iconeCirculo: { 
    width: 70, 
    height: 70, 
    borderRadius: 35, 
    backgroundColor: '#2ecc71', 
    justifyContent: 'center', 
    alignItems: 'center', 
    marginBottom: 15 
  },
  iconeCheck: { 
    color: '#FFF', 
    fontSize: 35, 
    fontWeight: 'bold' 
  },
  titulo: { 
    fontSize: 20, 
    fontWeight: 'bold', 
    color: '#1a2a3a', 
    marginBottom: 4 
  },
  pedidoNumero: { 
    fontSize: 14, 
    color: '#4169e1', 
    fontWeight: '500',
    marginBottom: 20
  },
  divisor: { 
    width: '100%', 
    height: 1, 
    backgroundColor: '#F0F0F0', 
    marginVertical: 15 
  },
  itensContainer: { 
    width: '100%', 
    alignItems: 'flex-start',
    paddingHorizontal: 5
  },
  itemTexto: { 
    fontSize: 14, 
    color: '#333', 
    marginBottom: 6 
  },
  infoBloco: { 
    width: '100%', 
    alignItems: 'flex-start',
    paddingHorizontal: 5
  },
  linhaTotal: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    width: '100%', 
    marginBottom: 10 
  },
  totalLabel: { 
    fontSize: 15, 
    fontWeight: 'bold', 
    color: '#1a2a3a' 
  },
  totalValor: { 
    fontSize: 15, 
    fontWeight: 'bold', 
    color: '#2ecc71' 
  },
  detalheTexto: { 
    fontSize: 13, 
    color: '#7f8c8d', 
    marginBottom: 4 
  },
  footer: { 
    padding: 20, 
    alignItems: 'center',
    backgroundColor: '#FFF'
  },
  btnNovoPedido: { 
    backgroundColor: '#2ecc71', 
    width: '100%', 
    paddingVertical: 14, 
    borderRadius: 12, 
    alignItems: 'center', 
    marginBottom: 8 
  },
  btnNovoPedidoText: { 
    color: '#FFF', 
    fontSize: 15, 
    fontWeight: 'bold' 
  },
  tagTela: { 
    fontSize: 12, 
    color: '#2ecc71', 
    fontWeight: '500' 
  }
});
